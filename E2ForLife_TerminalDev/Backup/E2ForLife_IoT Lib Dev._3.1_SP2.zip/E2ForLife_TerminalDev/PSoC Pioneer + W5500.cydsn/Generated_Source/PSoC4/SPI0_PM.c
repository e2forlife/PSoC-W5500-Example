/*******************************************************************************
* File Name: SPI0_PM.c
* Version 2.0
*
* Description:
*  This file provides the source code to the Power Management support for
*  the SCB Component.
*
* Note:
*
********************************************************************************
* Copyright 2013-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "SPI0.h"
#include "SPI0_PVT.h"

#if(SPI0_SCB_MODE_I2C_INC)
    #include "SPI0_I2C_PVT.h"
#endif /* (SPI0_SCB_MODE_I2C_INC) */

#if(SPI0_SCB_MODE_EZI2C_INC)
    #include "SPI0_EZI2C_PVT.h"
#endif /* (SPI0_SCB_MODE_EZI2C_INC) */

#if(SPI0_SCB_MODE_SPI_INC || SPI0_SCB_MODE_UART_INC)
    #include "SPI0_SPI_UART_PVT.h"
#endif /* (SPI0_SCB_MODE_SPI_INC || SPI0_SCB_MODE_UART_INC) */


/***************************************
*   Backup Structure declaration
***************************************/

#if(SPI0_SCB_MODE_UNCONFIG_CONST_CFG || \
   (SPI0_SCB_MODE_I2C_CONST_CFG   && (!SPI0_I2C_WAKE_ENABLE_CONST))   || \
   (SPI0_SCB_MODE_EZI2C_CONST_CFG && (!SPI0_EZI2C_WAKE_ENABLE_CONST)) || \
   (SPI0_SCB_MODE_SPI_CONST_CFG   && (!SPI0_SPI_WAKE_ENABLE_CONST))   || \
   (SPI0_SCB_MODE_UART_CONST_CFG  && (!SPI0_UART_WAKE_ENABLE_CONST)))

    SPI0_BACKUP_STRUCT SPI0_backup =
    {
        0u, /* enableState */
    };
#endif


/*******************************************************************************
* Function Name: SPI0_Sleep
********************************************************************************
*
* Summary:
*  Prepares the component to enter Deep Sleep.
*  The "Enable wakeup from Sleep Mode" selection has an influence on
*  this function implementation.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void SPI0_Sleep(void)
{
#if(SPI0_SCB_MODE_UNCONFIG_CONST_CFG)

    if(SPI0_SCB_WAKE_ENABLE_CHECK)
    {
        if(SPI0_SCB_MODE_I2C_RUNTM_CFG)
        {
            SPI0_I2CSaveConfig();
        }
        else if(SPI0_SCB_MODE_EZI2C_RUNTM_CFG)
        {
            SPI0_EzI2CSaveConfig();
        }
    #if(!SPI0_CY_SCBIP_V1)
        else if(SPI0_SCB_MODE_SPI_RUNTM_CFG)
        {
            SPI0_SpiSaveConfig();
        }
        else if(SPI0_SCB_MODE_UART_RUNTM_CFG)
        {
            SPI0_UartSaveConfig();
        }
    #endif /* (!SPI0_CY_SCBIP_V1) */
        else
        {
            /* Unknown mode */
        }
    }
    else
    {
        SPI0_backup.enableState = (uint8) SPI0_GET_CTRL_ENABLED;

        if(0u != SPI0_backup.enableState)
        {
            SPI0_Stop();
        }
    }

#else

    #if (SPI0_SCB_MODE_I2C_CONST_CFG && SPI0_I2C_WAKE_ENABLE_CONST)
        SPI0_I2CSaveConfig();

    #elif (SPI0_SCB_MODE_EZI2C_CONST_CFG && SPI0_EZI2C_WAKE_ENABLE_CONST)
        SPI0_EzI2CSaveConfig();

    #elif (SPI0_SCB_MODE_SPI_CONST_CFG && SPI0_SPI_WAKE_ENABLE_CONST)
        SPI0_SpiSaveConfig();

    #elif (SPI0_SCB_MODE_UART_CONST_CFG && SPI0_UART_WAKE_ENABLE_CONST)
        SPI0_UartSaveConfig();

    #else

        SPI0_backup.enableState = (uint8) SPI0_GET_CTRL_ENABLED;

        if(0u != SPI0_backup.enableState)
        {
            SPI0_Stop();
        }

    #endif /* defined (SPI0_SCB_MODE_I2C_CONST_CFG) && (SPI0_I2C_WAKE_ENABLE_CONST) */

#endif /* (SPI0_SCB_MODE_UNCONFIG_CONST_CFG) */
}


/*******************************************************************************
* Function Name: SPI0_Wakeup
********************************************************************************
*
* Summary:
*  Prepares the component for the Active mode operation after exiting
*  Deep Sleep. The "Enable wakeup from Sleep Mode" option has an influence
*  on this function implementation.
*  This function should not be called after exiting Sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void SPI0_Wakeup(void)
{
#if(SPI0_SCB_MODE_UNCONFIG_CONST_CFG)

    if(SPI0_SCB_WAKE_ENABLE_CHECK)
    {
        if(SPI0_SCB_MODE_I2C_RUNTM_CFG)
        {
            SPI0_I2CRestoreConfig();
        }
        else if(SPI0_SCB_MODE_EZI2C_RUNTM_CFG)
        {
            SPI0_EzI2CRestoreConfig();
        }
    #if(!SPI0_CY_SCBIP_V1)
        else if(SPI0_SCB_MODE_SPI_RUNTM_CFG)
        {
            SPI0_SpiRestoreConfig();
        }
        else if(SPI0_SCB_MODE_UART_RUNTM_CFG)
        {
            SPI0_UartRestoreConfig();
        }
    #endif /* (!SPI0_CY_SCBIP_V1) */
        else
        {
            /* Unknown mode */
        }
    }
    else
    {
        if(0u != SPI0_backup.enableState)
        {
            SPI0_Enable();
        }
    }

#else

    #if (SPI0_SCB_MODE_I2C_CONST_CFG  && SPI0_I2C_WAKE_ENABLE_CONST)
        SPI0_I2CRestoreConfig();

    #elif (SPI0_SCB_MODE_EZI2C_CONST_CFG && SPI0_EZI2C_WAKE_ENABLE_CONST)
        SPI0_EzI2CRestoreConfig();

    #elif (SPI0_SCB_MODE_SPI_CONST_CFG && SPI0_SPI_WAKE_ENABLE_CONST)
        SPI0_SpiRestoreConfig();

    #elif (SPI0_SCB_MODE_UART_CONST_CFG && SPI0_UART_WAKE_ENABLE_CONST)
        SPI0_UartRestoreConfig();

    #else

        if(0u != SPI0_backup.enableState)
        {
            SPI0_Enable();
        }

    #endif /* (SPI0_I2C_WAKE_ENABLE_CONST) */

#endif /* (SPI0_SCB_MODE_UNCONFIG_CONST_CFG) */
}


/* [] END OF FILE */
